import { Component, OnInit, Input } from '@angular/core';
import { ArmamentModel } from '../../shared/models/armament';
import { ApplicationContext } from '../../application-context';
import { LookupService } from '../../shared/services/lookup.service';
import { LookupEnum } from '../../shared/enums/lookup.enum';
import { LookupData } from '../../shared/models/result';

declare var $: any;


@Component({
  selector: 'cdss-armament-detail',
  templateUrl: './armament-detail.component.html',
  styleUrls: ['./armament-detail.component.css']
})
export class ArmamentDetailComponent implements OnInit {

  private _isEditMode: boolean;
  private _lang: string;
  private _datasource: ArmamentModel;
  //-------------------------------------------
  constructor(private app:ApplicationContext, private lookup:LookupService) {
    this._isEditMode = false;
    this._lang = 'th';

    if(app.isDevMode) this.mockupData();
  }

  ngOnInit() {
  }

  ngAfterViewInit(): void {

    //this.swapMode(this._isEditMode);
  }
  //-------------------------------------------
  //-------------------------------------------
  @Input()
  public get isEditMode(): boolean {
    return this._isEditMode;
  }
  public set isEditMode(value: boolean) {
//    console.log('isEditMode : ', this.isEditMode);
    if (this._isEditMode != value) {
      this._isEditMode = value;
      //this.swapMode(this._isEditMode);
    }
  }
  //-------------------------------------------
  @Input()
  public get language(): string {
    return this._lang;
  }
  public set language(value: string) {
    if (this._lang != value) {
      this._lang = value;

      //if (this._isEditMode) this.swapMode(this._isEditMode);
    }

  }
  //-------------------------------------------
  @Input()
  public get datasource(): ArmamentModel {
    return this._datasource;
  }
  public set datasource(value: ArmamentModel) {
    this._datasource = value;
  }
  //-------------------------------------------
  //-------------------------------------------
  public get armamentType():Array<LookupData> {
    return this.lookup.getLookup(LookupEnum.ArmamentType);
  }
  //-------------------------------------------
  public get armamentGroup(): Array<LookupData> {
    return this.lookup.getLookup(LookupEnum.ArmamentGroup);
  }
  //-------------------------------------------
  public get unitType(): Array<LookupData> {
    return this.lookup.getLookup(LookupEnum.UnitType);
  }
  //-------------------------------------------
  public get weightType(): Array<LookupData> {
    return this.lookup.getLookup(LookupEnum.WeightType);
  }
  //-------------------------------------------
  public get packageType(): Array<LookupData> {
    return this.lookup.getLookup(LookupEnum.PackageType);
  }
  //-------------------------------------------
  //private swapMode(value) {
  //  if (value) {
  //    $('#txtRegisterDate').datepicker({
  //      language: this._lang
  //    });
  //  } else {
  //    $('#txtRegisterDate').datepicker('destroy');
  //  }
  //}
  //-------------------------------------------
  public searchTariff() {
    alert('searchTariff');
  }
  //-------------------------------------------
  //-------------------------------------------
  private mockupData() {
    this._datasource = new ArmamentModel();

    this._datasource.name = "โตโยต้า โคคา โคล่า";
    this._datasource.brand = "Toyota";
    this._datasource.description = "มันคือรถ 1 คัน ตัวฉันมีรถ 3 คัน หากซื้อใหม่ 2 คัน จะกลายเป็นฉันมีรถ 5 คัน, ซึ่งดูเหมือนมันจะมากไป";
    this._datasource.groupCode = "G1";
    this._datasource.groupName = "ยุทธภัณฑ์ 1";
    this._datasource.ingredient = "something like that !!!";
    this._datasource.model = "Corolla";
    this._datasource.packageCode = "BOX";
    this._datasource.packageName = "กล่อง";
    this._datasource.packageCount = 1;
    this._datasource.remark = "ได้จ่ะพี่ ดีจ่ะน้อง สอดคล้องค่ะเพื่อน";
    this._datasource.statisticCode = "6*2=12";
    this._datasource.tariff = "Lertpanya Building";
    this._datasource.tariffCode = "@13.7594844,100.5363664,19.75z";
    this._datasource.typeCode = "T2";
    this._datasource.typeName = "อาวุธชนิด 2";
    this._datasource.unitCount = 2;
    this._datasource.unitName = "ชิ้น";
    this._datasource.unitCode = "PN";

    this._datasource.weight = 50;
    this._datasource.weightCode = "PD";
    this._datasource.weightName = "ปอนด์";
    
  }

}
