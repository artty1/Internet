import { Component, Input, OnInit, AfterViewInit } from '@angular/core';
import { PersonModel } from '../../shared/models/person';

declare var $: any;

@Component({
  selector: 'cdss-person-detail',
  templateUrl: './person-detail.component.html',
  styleUrls: ['./person-detail.component.css']
})
export class PersonDetailComponent implements OnInit, AfterViewInit {

  private _isEditMode: boolean;
  private _lang: string;
  private _datasource: PersonModel;
  //-------------------------------------------
  constructor() {
    this.isEditMode = false;
    this._lang = 'th';

    this.mockupData();
  }
  ngOnInit() {
  }

  ngAfterViewInit(): void {

    this.swapMode(this._isEditMode);
  }
  //-------------------------------------------
  //-------------------------------------------
  @Input()
  public get isEditMode(): boolean {
    return this._isEditMode;
  }
  public set isEditMode(value: boolean) {

    if (this._isEditMode != value) {
      this._isEditMode = value;
      this.swapMode(this._isEditMode);

    }
  }
  //-------------------------------------------
  @Input()
  public get language(): string {
    return this._lang;
  }
  public set language(value: string) {
    if (this._lang != value) {
      this._lang = value;

      if (this._isEditMode) this.swapMode(this._isEditMode);
    }

  }
  //-------------------------------------------
  @Input()
  public get datasource(): PersonModel {
    return this._datasource;
  }
  public set datasource(value: PersonModel) {
      this._datasource = value;
  }
  //-------------------------------------------
  //-------------------------------------------
  private swapMode(value) {
    if (value) {
      $('#txtRegisterDate').datepicker({
        language: this._lang
      });
    } else {
      $('#txtRegisterDate').datepicker('destroy');
    }
  }

    //-------------------------------------------
  //-------------------------------------------
  private mockupData() {
    this._datasource = new PersonModel();

    this._datasource.taxID = "3101400336736";
    this._datasource.addressBuilding = "พรีม่าศรีนครินทร์";
    this._datasource.addressDistrict = "สวนหลวง";
    this._datasource.addressSubDistrict = "อ่อนนุช";
    this._datasource.addressMoo = "";
    this._datasource.addressNo = "1134/223";
    this._datasource.addressProvince = "กทม.";
    this._datasource.addressSoi = "";
    this._datasource.addressStreet = "ศรีนครินทร์";
    this._datasource.addressVillage = "";
    this._datasource.addressZipcode = "10250";
    this._datasource.email = "monchai@outlook.com";
    this._datasource.fax = "";
    
    this._datasource.prefixName = "นาย";
    this._datasource.firstName = "มนต์ชัย";
    this._datasource.lastName = "หิรัญเบญจทรัพย์";
    this._datasource.phone = "0824526688";
    

  }

}
