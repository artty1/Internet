import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { EventResult } from '../../shared/models/result';
import { ApplicationContext } from '../../application-context';
import { Address } from '../../shared/models/common';
import { PopupListLocation } from '../popup-list-location/popup-list-location.component';
import { baseModalDialog } from '../../shared/base/base-modal-dialog';

@Component({
  selector: 'cdss-editor-location-dialog',
  templateUrl: './editor-location-dialog.component.html',
  styleUrls: ['./editor-location-dialog.component.css']
})
//export class EditorLocationDialogComponent implements OnInit {
export class EditorLocationDialog extends baseModalDialog implements OnInit {

  //private editor: ModalDialogComponent;
  private popup: PopupListLocation;

  //@Output("ready") onReady: EventEmitter<EventResult> = new EventEmitter();
  //@Output("close") onClose: EventEmitter<EventResult> = new EventEmitter();
  //@Output("complete") onComplete: EventEmitter<EventResult> = new EventEmitter();
  //@Output("cancel") onCancel: EventEmitter<EventResult> = new EventEmitter();

  private currentAddress: Address;
  private is_lock: boolean;
  private has_reference_to_address: boolean;
  //private for_production:number;
  private for_production:boolean;
  //-----------------------------------------------
  constructor(public app: ApplicationContext) {

    super();
    //this.for_production = 1;
    this.init();
  }
  //-----------------------------------------------
  ngOnInit() {

  }
  //-----------------------------------------------
  // @Input("forProduction")
  // public get forProduction():number{
  //   return this.for_production;
  // }
  // public set forProduction(value:number){
  //   this.for_production = value;
  //   console.log('set forProduction : ', value);
  // }
  //-----------------------------------------------
  public init(){
    this.currentAddress = new Address();
    this.has_reference_to_address = false;
    this.is_lock = false;
  }
  //-----------------------------------------------
  //public initDialog(args: EventResult) {
  //  this.editor = args.sender;

  //  let result = new EventResult();

  //  result.sender = this;
  //  result.data = null

  //  this.onReady.emit(result);

  //}
  //-----------------------------------------------
  //public initLocationPopup(args: EventResult){
  //  this.popup = args.sender;
  //}
//-----------------------------------------------
public showEditorForProduction() {
  this.init();
  this.for_production = true;
  //this.editor.showDialog();
  this.openDialog();
}
//-----------------------------------------------
public showEditorForStock() {
  this.init();
  this.for_production = false;
  //this.editor.showDialog();
  this.openDialog();
}
//-----------------------------------------------
//public closeDialog(args: EventResult) {

//    let result = new EventResult();

//    result.data = null;
//    result.sender = this;

//    //this.onClose.emit(result);

//  }
  //-----------------------------------------------
  //public showEditor() {
  //  this.editor.showDialog(args => {

  //    let result = new EventResult();

  //    result.data = null;
  //    result.sender = this;

  //    if (args.data == this.RESULT_COMPLETE) {
  //      //result.data = 
  //      this.onComplete.emit(result);
  //    } else {
  //      this.onCancel.emit(result);
  //    }


  //  });
  //}
  //-----------------------------------------------
  public get address(): Address {
    return this.currentAddress;
  }
  //-----------------------------------------------
  public get isLock() {
    return this.is_lock;
  }
  //-----------------------------------------------
  public get isShowLockCheckbox() {
    return this.has_reference_to_address;
  }
  //-----------------------------------------------
  public getAddressFromTraderProfile() {
    //--------------------------------------

    this.currentAddress.ID = -1;
    this.currentAddress.LOCATION_NAME = this.app.traderInformation.TRADER_NAME;
    this.currentAddress.ADDRESS_NO = this.app.traderInformation.ADDRESS_NO;
    this.currentAddress.BUILDING_NAME = this.app.traderInformation.BUILDING_NAME;
    this.currentAddress.VILLAGE = this.app.traderInformation.VILLAGE;
    this.currentAddress.MOO = this.app.traderInformation.MOO;
    this.currentAddress.SOI = this.app.traderInformation.SOI;
    this.currentAddress.STREET = this.app.traderInformation.STREET;
    this.currentAddress.DISTRICT_NAME = this.app.traderInformation.DISTRICT_NAME;
    this.currentAddress.SUB_PROVINCE_NAME = this.app.traderInformation.SUB_PROVINCE_NAME;
    this.currentAddress.PROVINCE_NAME = this.app.traderInformation.PROVINCE_NAME;
    this.currentAddress.POSTCODE = this.app.traderInformation.POSTCODE;
    this.currentAddress.PHONE_NO = this.app.traderInformation.PHONE_NO;
    this.currentAddress.FAX_NO = this.app.traderInformation.FAX_NO;
    this.currentAddress.E_MAIL_ADDRESS = this.app.traderInformation.E_MAIL_ADDRESS;

    this.has_reference_to_address = true;
    this.is_lock = true;

  }
  //-----------------------------------------------
  public showAddressList() {
    this.popup.OpenDialog();
    //this.openDialog();
  }
  //-----------------------------------------------
  public getLocation(args:EventResult){
    this.currentAddress = args.data;

    this.has_reference_to_address = true;
    this.is_lock = true;
    
  }
}
